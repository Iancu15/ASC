#!/bin/bash

time ./gpu_sol 127 ../tests/B0.in ../tests/B0.out