# usage: test_generator.py [-h] test_name [producers] [consumers] [products] [marketplace_q] [min_carts] [max_carts] [is_basic] [supports_removal]

python3 test_generator.py 01 1 1 2 15 1 1 False
python3 test_generator.py 02 1 1 2 15 2 2
python3 test_generator.py 03 1 5 1 12 1 2 False
python3 test_generator.py 04 5 1 3 13 10 10
python3 test_generator.py 05 3 5 5 50 1 3 False
python3 test_generator.py 06 5 5 3 30 1 3
python3 test_generator.py 07 5 10 5 40 1 5
python3 test_generator.py 08 10 50 5 40 1 5
python3 test_generator.py 09 20 5 2 25 1 2
python3 test_generator.py 10 50 200 10 40 1 5

